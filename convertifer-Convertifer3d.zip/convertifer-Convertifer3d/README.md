# convertifer
AFMG Ease / D&amp;B / L-Acoustic Venue converter

Javascript thing for converting between venue models. 
Ease Focus -> D&B ArrayCalc -> L-Acoustic Network Manager
